var clickBotao = document.getElementById('clickBotao');
var clickCountDisplay = document.getElementById('clickCount');

var clickCount = 0;

clickBotao.addEventListener('click', function() {
    clickCount++;
     clickCountDisplay.textContent = clickCount;
    });
