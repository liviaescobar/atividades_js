var hoverImage = document.getElementById('hoverImage');

hoverImage.addEventListener('mouseover', function() {
    alert('Flor bonita!');
});