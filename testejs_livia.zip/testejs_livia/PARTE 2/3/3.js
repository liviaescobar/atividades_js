var messageButton = document.getElementById('messageButton');

messageButton.addEventListener('click', function() {
    alert('Mensagem de teste.');
});
