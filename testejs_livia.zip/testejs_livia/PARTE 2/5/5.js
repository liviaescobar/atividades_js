var textInput = document.getElementById('textInput');
var submitButton = document.getElementById('submitButton');

// Adiciona um evento de clique ao botão de envio
submitButton.addEventListener('click', function() {
    // Verifica se o campo de entrada está vazio
    if (textInput.value.trim() === '') {
        // Se estiver vazio, adiciona a classe 'error' para destacar em vermelho
        textInput.classList.add('error');
    } else {
        // Se não estiver vazio, remove a classe 'error'
        textInput.classList.remove('error');
    }
});
