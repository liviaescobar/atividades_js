function exibirSaudacao(){
    var nome7 = document.getElementById("nome7").value;
    var sobrenome = document.getElementById("sobrenome").value;
    var saudacao = "Olá " + nome7 + " " + sobrenome;
    alert(saudacao);
}