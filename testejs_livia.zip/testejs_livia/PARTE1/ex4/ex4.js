    var botao = document.getElementById('botao');

    botao.addEventListener('click', function() {
        var nomeInput = document.getElementById('nome');
        var nome = nomeInput.value.trim();

        if (nome !== '') {
            alert('O Nome Completo é: "' + nome);
            var quantletras = nome.length;
            alert('Quantidade de letras: ' + quantletras);
        } else {
            alert('Insira algo');
        }
    });