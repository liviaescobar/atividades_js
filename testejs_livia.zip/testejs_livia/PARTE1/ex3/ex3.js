const num1 = 1;
const num2 = 7;

const soma = (num1 + num2);

alert(soma);