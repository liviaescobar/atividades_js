document.getElementById("lampada").addEventListener("mouseover", function(){
    let img = document.getElementById("lampada");

    if(img.src.match("lampada_apagada.jpeg")){
        img.src = "lampada_acesa.jpeg";
    } else {
        img.src = "lampada_apagada.jpeg";
    }
})