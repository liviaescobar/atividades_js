function alterarCor(cor){
    document.getElementById("elemento").style.backgroundColor = cor;
}